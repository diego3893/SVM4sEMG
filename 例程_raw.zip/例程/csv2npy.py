import csv
import numpy as np
import pandas as pd


def dataconvert(loadfilename, savefilename):
    data_all = []
    index = [0, 1, 11, 21]

    csvreader = pd.read_csv(loadfilename)

    data_all = csvreader.to_numpy()
    data_all = data_all[:, index]
    np.save(savefilename, data_all)


if __name__ == "__main__":
    # TODO: Implement this
    dataconvert(
        "C:/Users/swg/Desktop/实验课/例程/Participant1_Gait_Rep_1.5.csv",
        "C:/Users/swg/Desktop/实验课/例程/data1.npy",
    )
